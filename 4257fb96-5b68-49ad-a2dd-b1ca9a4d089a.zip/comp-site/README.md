# comp site

A standalone responsive website inspired by the visible layout of mspaint.cc, with the script name changed to `comp`.

## Run
Open `index.html` in a modern browser, or serve this folder:
`python -m http.server 8000`

The editor and Copy script button work locally. This is an independent recreation, not the original site's backend, accounts, dashboard, or executor integrations.
